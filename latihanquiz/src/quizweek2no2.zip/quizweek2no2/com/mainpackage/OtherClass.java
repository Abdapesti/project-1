package quizweek2no2.com.mainpackage;

public class OtherClass {

	public static void main(String[] args) {
		SameClass n = new SameClass();
		n.Nama();
		n.NPMNIM();
		n.MTK();
		n.Bindo();
		n.PBO();
		System.out.println();
		n.Mean();

	}

}
