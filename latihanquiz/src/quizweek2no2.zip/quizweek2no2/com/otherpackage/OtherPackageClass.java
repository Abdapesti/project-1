package quizweek2no2.com.otherpackage;

import quizweek2no2.com.mainpackage.SameClass;

public class OtherPackageClass {

	public static void main(String[] args) {

		SameClass c = new SameClass();
		c.Nama();
		c.NPMNIM();
		c.MTK();
		c.Bindo();
		c.PBO();
		System.out.println();
		c.Mean();
	}

}
